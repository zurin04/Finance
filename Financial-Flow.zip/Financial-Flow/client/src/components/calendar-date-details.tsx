import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Calendar, DollarSign, Receipt, CheckSquare, BookOpen, FileText, CalendarDays } from "lucide-react";
import { format } from "date-fns";

interface CalendarDateDetailsProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate: Date | null;
}

export default function CalendarDateDetails({ isOpen, onClose, selectedDate }: CalendarDateDetailsProps) {
  const dateStr = selectedDate ? format(selectedDate, "yyyy-MM-dd") : "";

  const { data: income } = useQuery({
    queryKey: ["/api/income"],
    enabled: isOpen && !!selectedDate,
  });

  const { data: expenses } = useQuery({
    queryKey: ["/api/expenses"],
    enabled: isOpen && !!selectedDate,
  });

  const { data: tasks } = useQuery({
    queryKey: ["/api/tasks"],
    enabled: isOpen && !!selectedDate,
  });

  const { data: bills } = useQuery({
    queryKey: ["/api/bills"],
    enabled: isOpen && !!selectedDate,
  });

  const { data: notes } = useQuery({
    queryKey: ["/api/notes", { date: dateStr }],
    queryFn: () => fetch(`/api/notes?date=${dateStr}`).then(res => res.json()),
    enabled: isOpen && !!selectedDate,
  });

  if (!selectedDate) return null;

  const dayIncome = income?.filter((item: any) => item.date === dateStr) || [];
  const dayExpenses = expenses?.filter((item: any) => item.date === dateStr) || [];
  const dayTasks = tasks?.filter((item: any) => item.dueDate === dateStr) || [];
  const dayBills = bills?.filter((item: any) => item.dueDate === dateStr) || [];
  const dayNotes = notes?.filter((note: any) => note.noteDate === dateStr) || [];
  const dayDiary = dayNotes.filter((note: any) => note.noteType === "diary");
  const dayRegularNotes = dayNotes.filter((note: any) => note.noteType === "note");

  const totalIncome = dayIncome.reduce((sum: number, item: any) => sum + parseFloat(item.amount), 0);
  const totalExpenses = dayExpenses.reduce((sum: number, item: any) => sum + parseFloat(item.amount), 0);
  const netAmount = totalIncome - totalExpenses;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Calendar className="w-5 h-5" />
            {format(selectedDate, "EEEE, MMMM d, yyyy")}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Daily Summary */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-medium text-gray-900 mb-3">Daily Summary</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-600">${totalIncome.toFixed(2)}</div>
                <div className="text-sm text-gray-600">Income</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-red-600">${totalExpenses.toFixed(2)}</div>
                <div className="text-sm text-gray-600">Expenses</div>
              </div>
              <div>
                <div className={`text-2xl font-bold ${netAmount >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  ${netAmount.toFixed(2)}
                </div>
                <div className="text-sm text-gray-600">Net P&L</div>
              </div>
            </div>
          </div>

          {/* Income Section */}
          {dayIncome.length > 0 && (
            <div>
              <h3 className="flex items-center gap-2 font-medium text-gray-900 mb-3">
                <DollarSign className="w-4 h-4 text-green-600" />
                Income ({dayIncome.length})
              </h3>
              <div className="space-y-2">
                {dayIncome.map((item: any) => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                    <div>
                      <div className="font-medium text-gray-900">{item.description}</div>
                      <div className="text-sm text-gray-600">Category: {item.category}</div>
                    </div>
                    <div className="text-lg font-semibold text-green-600">
                      +${parseFloat(item.amount).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Expenses Section */}
          {dayExpenses.length > 0 && (
            <div>
              <h3 className="flex items-center gap-2 font-medium text-gray-900 mb-3">
                <Receipt className="w-4 h-4 text-red-600" />
                Expenses ({dayExpenses.length})
              </h3>
              <div className="space-y-2">
                {dayExpenses.map((item: any) => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                    <div>
                      <div className="font-medium text-gray-900">{item.description}</div>
                      <div className="text-sm text-gray-600">Category: {item.category}</div>
                    </div>
                    <div className="text-lg font-semibold text-red-600">
                      -${parseFloat(item.amount).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tasks Section */}
          {dayTasks.length > 0 && (
            <div>
              <h3 className="flex items-center gap-2 font-medium text-gray-900 mb-3">
                <CheckSquare className="w-4 h-4 text-blue-600" />
                Tasks ({dayTasks.length})
              </h3>
              <div className="space-y-2">
                {dayTasks.map((task: any) => (
                  <div key={task.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{task.title}</div>
                      {task.description && (
                        <div className="text-sm text-gray-600 mt-1">{task.description}</div>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant={task.priority === 'High' ? 'destructive' : task.priority === 'Medium' ? 'default' : 'secondary'}>
                          {task.priority}
                        </Badge>
                        <Badge variant="outline">{task.category}</Badge>
                      </div>
                    </div>
                    <Badge variant={task.status === 'Completed' ? 'default' : 'secondary'}>
                      {task.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Bills Section */}
          {dayBills.length > 0 && (
            <div>
              <h3 className="flex items-center gap-2 font-medium text-gray-900 mb-3">
                <Receipt className="w-4 h-4 text-orange-600" />
                Bills Due ({dayBills.length})
              </h3>
              <div className="space-y-2">
                {dayBills.map((bill: any) => (
                  <div key={bill.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
                    <div>
                      <div className="font-medium text-gray-900">{bill.description}</div>
                      <div className="text-sm text-gray-600">Due Date: {format(new Date(bill.dueDate), "MMM d, yyyy")}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-lg font-semibold text-orange-600">
                        ${parseFloat(bill.amount).toFixed(2)}
                      </div>
                      <Badge variant={bill.status === 'Paid' ? 'default' : 'destructive'}>
                        {bill.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Diary Entries Section */}
          {dayDiary.length > 0 && (
            <div>
              <h3 className="flex items-center gap-2 font-medium text-gray-900 mb-3">
                <CalendarDays className="w-4 h-4 text-purple-600" />
                Diary Entries ({dayDiary.length})
              </h3>
              <div className="space-y-3">
                {dayDiary.map((entry: any) => (
                  <div key={entry.id} className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">{entry.title}</h4>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-purple-600 border-purple-300">
                          {entry.category}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {format(new Date(entry.createdAt), "h:mm a")}
                        </span>
                      </div>
                    </div>
                    <div className="text-sm text-gray-700 whitespace-pre-wrap">
                      {entry.content}
                    </div>
                    {entry.tags && entry.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {entry.tags.map((tag: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notes Section */}
          {dayRegularNotes.length > 0 && (
            <div>
              <h3 className="flex items-center gap-2 font-medium text-gray-900 mb-3">
                <BookOpen className="w-4 h-4 text-indigo-600" />
                Notes ({dayRegularNotes.length})
              </h3>
              <div className="space-y-3">
                {dayRegularNotes.map((note: any) => (
                  <div key={note.id} className="p-4 bg-indigo-50 rounded-lg border border-indigo-200">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">{note.title}</h4>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-indigo-600 border-indigo-300">
                          {note.category}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {format(new Date(note.createdAt), "h:mm a")}
                        </span>
                      </div>
                    </div>
                    <div className="text-sm text-gray-700 whitespace-pre-wrap">
                      {note.content}
                    </div>
                    {note.tags && note.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {note.tags.map((tag: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Empty State */}
          {dayIncome.length === 0 && dayExpenses.length === 0 && dayTasks.length === 0 && dayBills.length === 0 && dayNotes.length === 0 && (
            <div className="text-center py-12">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No activities on this date</h3>
              <p className="text-gray-600">No income, expenses, tasks, bills, or notes were recorded for this day.</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}